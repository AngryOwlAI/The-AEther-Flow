# Exact-GR interpretive manuscript package: reproducibility instructions

Status: internal release candidate; external publication, submission, outreach,
push, and distribution remain human-gated and are not authorized by this bundle.

## Environment

- Python: `>=3.12,<3.13`
- Runtime dependency lock: `research_control/tasks/RT-20260723-019/artifacts/requirements.lock`
- Full quality lock: `research_control/tasks/RT-20260724-002/artifacts/quality-assurance-requirements.lock`
- Install from the extracted bundle root with `python -m pip install --require-hashes -r requirements-dev.txt`.

## Reproduce

Run from the extracted bundle root:

```sh
    python research_control/tasks/RT-20260722-021/artifacts/validate_exact_gr_interpretive_package.py --check --json
```

The expected result is process exit code zero. Validator PASS is operational
evidence only; it is not theorem proof, ontology adoption, benchmark promotion,
publication authority, or completed derivation.

## Limitations

- The source snapshot predates later canonical edits to foundations, dynamics, and geometry.
- The manuscript is a noncanonical internal publication candidate, not an adopted derivation or release authorization.

## License and notice

`LICENSE` assigns research and documentation content to CC BY 4.0 and code or
tooling to Apache-2.0, subject to narrower notices. `NOTICES` records attribution
and third-party boundaries. The repository currently tracks the split-license
summary rather than standalone copies of the two standard license texts; stable
license identifiers and official text URLs are recorded in the package catalog.
